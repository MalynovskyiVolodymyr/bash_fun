#!/bin/bash

some_func(){
	caller 0
}

some_func
