#!/bin/bash
# uppercase Changes input to upper case

tr 'a-z' 'A-Z'
# Letter ranges must be quoted to prevent filename generagion

exit 0

